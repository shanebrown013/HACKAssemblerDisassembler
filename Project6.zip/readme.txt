To run my program, frist compile with g++ (g++ assembler.cpp and g++ disassembler.cpp),
 then type "./a.out [inputFileName].txt". A file will be generated with the correct
content. The assembler generates a .hack file and the disassembler generates a .asm file.
I passed all the tests on my machine wih no problems.

I included the test files however, PUT THEM IN THE SAME DIRECTORY TO RUN THEM.